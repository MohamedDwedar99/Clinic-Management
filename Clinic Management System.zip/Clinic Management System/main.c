#include <stdio.h>
#include "APP/app.h"
void main(void)
{
	start_app();
}
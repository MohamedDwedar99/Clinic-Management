#ifndef 	APP_H
#define	APP_H

void start_app(void);

#endif